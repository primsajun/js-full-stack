# Sea Sentiment (React + Express + MongoDB)

This project is a minimal sentiment analysis web app with:

- Backend: Node.js + Express + MongoDB (Mongoose) with a POST endpoint `/api/sentiment`.
- Frontend: React (Vite) with a centered textarea and submit button using a sea-themed design.
- Sentiment analysis: `sentiment` npm package (simple rule-based scoring).

Quick start

1. Open this folder `C:/Users/Admin/Downloads/dappa`.

2. Start MongoDB locally or provide a connection string in `server/.env` (see `.env.example`).

3. Install and run the server:

```powershell
cd server
npm install
npm run dev
```

Server runs on port 5000 by default.

4. Install and run the client:

```powershell
cd client
npm install
npm run dev
```

Client runs on port 3000 and proxies `/api` to `http://localhost:5000`.

Postman

- POST `http://localhost:5000/api/sentiment`
- Body (JSON): `{ "text": "I love the ocean" }`
- Response: `{ "id": "..", "label": "positive", "score": 3, "text": "I love the ocean" }`

Notes

- The sentiment analysis is basic and uses the `sentiment` package for quick demos.
- Customize styling in `client/src/index.css`.

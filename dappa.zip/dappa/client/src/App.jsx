import React, { useState, useEffect, useRef } from 'react'

export default function App() {
  const [text, setText] = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    if (!text.trim()) return
    setLoading(true)
    try {
      const res = await fetch('/api/sentiment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      })
      const data = await res.json()
      if (res.ok) setResult(data)
      else setResult({ error: data.error || 'Unknown error' })
    } catch (err) {
      setResult({ error: err.message })
    } finally {
      setLoading(false)
    }
  }

  const trailRef = useRef(null)

  useEffect(() => {
    const colors = ['#00a896', '#028090', '#05668d', '#00d4b3', '#66e1d3', '#7fe9de']
    const container = trailRef.current
    if (!container) return

    function onMove(e) {
      const size = 14 + Math.random() * 14
      const dot = document.createElement('span')
      dot.className = 'trail-dot'
      const color = colors[Math.floor(Math.random() * colors.length)]
      dot.style.left = (e.clientX - size / 2) + 'px'
      dot.style.top = (e.clientY - size / 2) + 'px'
      dot.style.width = size + 'px'
      dot.style.height = size + 'px'
      dot.style.background = color
      container.appendChild(dot)
      setTimeout(() => {
        dot.remove()
      }, 900)
    }

    window.addEventListener('mousemove', onMove)
    return () => window.removeEventListener('mousemove', onMove)
  }, [])

  return (
    <div className="sea-root">
      <main className="card">
        <form onSubmit={handleSubmit} className="form">
          <textarea
            placeholder="Type your text here..."
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <button type="submit" disabled={loading}>{loading ? 'Analyzing...' : 'Submit'}</button>
        </form>

        {result && (
          <div className="result">
            {result.error ? (
              <div className="error">Error: {result.error}</div>
            ) : (
              <div className={`label ${result.label}`}>Label: {result.label}</div>
            )}
          </div>
        )}
      </main>
      <div ref={trailRef} className="trail-container" aria-hidden="true" />
    </div>
  )
}

const mongoose = require('mongoose');

const SentimentSchema = new mongoose.Schema({
  text: { type: String, required: true },
  score: { type: Number, required: true },
  label: { type: String, enum: ['positive','negative','neutral'], required: true },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Sentiment', SentimentSchema);
